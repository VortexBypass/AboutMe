// small helper for nav active state (optional)
document.addEventListener('DOMContentLoaded', () => {
  // nothing required for now; script file kept for easy future additions
});
